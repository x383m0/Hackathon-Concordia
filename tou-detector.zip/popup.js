const resultDiv = document.getElementById("result");

function show(cls, content) {
  resultDiv.className = cls;
  resultDiv.style.display = "block";
  resultDiv.replaceChildren(content);
}

function text(str) {
  const p = document.createElement("div");
  p.textContent = str; // textContent: le texte vient de la page, jamais en innerHTML
  return p;
}

function safeLink(url) {
  // N'accepte que http(s) pour éviter les liens javascript:
  if (!/^https?:\/\//i.test(url)) return null;
  const a = document.createElement("a");
  a.href = url;
  a.target = "_blank";
  a.textContent = url;
  return a;
}

function addLink(parent, url) {
  const link = url && safeLink(url);
  if (link) parent.appendChild(link);
}

document.getElementById("check").addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Injecte detector.js dans la page ET dans toutes ses iframes
    const injected = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ["detector.js"]
    });

    // Un résultat par cadre (page principale + iframes) : on les regroupe
    const frames = injected.map(r => r.result).filter(Boolean);
    const checkboxes = frames.flatMap(f => f.checkboxes);
    const implicit = frames.flatMap(f => f.implicit);

    if (checkboxes.length + implicit.length === 0) {
      const box = document.createElement("div");
      box.appendChild(text("❌ Aucun ToU à accepter détecté."));

      // Diagnostic : ce que chaque cadre contient
      const diag = document.createElement("div");
      diag.style.cssText = "margin-top:8px;font-size:11px;opacity:.85";
      diag.appendChild(text(`Cadres analysés : ${frames.length}`));
      for (const f of frames) {
        const d = f.debug;
        diag.appendChild(text(
          `• ${f.page.slice(0, 55)} → liens ToU: ${d.termsLinks}, boutons: ${d.buttons}, cases: ${d.checkboxes}`
        ));
      }
      box.appendChild(diag);

      // Diagnostic détaillé à copier-coller pour comprendre pourquoi rien n'est détecté
      const report = JSON.stringify(frames.map(f => ({ page: f.page, debug: f.debug })), null, 1);
      const ta = document.createElement("textarea");
      ta.value = report;
      ta.readOnly = true;
      ta.rows = 5;
      ta.style.cssText = "width:100%;margin-top:8px;font-size:10px;box-sizing:border-box";
      const copy = document.createElement("button");
      copy.textContent = "Copier le diagnostic";
      copy.style.marginTop = "6px";
      copy.addEventListener("click", () => {
        ta.select();
        document.execCommand("copy");
        copy.textContent = "Copié ✓";
      });
      box.appendChild(ta);
      box.appendChild(copy);

      show("no", box);
      return;
    }

    const box = document.createElement("div");
    const total = checkboxes.length + implicit.length;
    box.appendChild(text(`✅ ${total} acceptation${total > 1 ? "s" : ""} de ToU détectée${total > 1 ? "s" : ""}`));

    // Cases à cocher
    for (const c of checkboxes) {
      const item = document.createElement("div");
      item.style.marginTop = "8px";
      item.appendChild(text(`${c.checked ? "☑" : "☐"} Case à cocher : « ${c.label} »`));
      addLink(item, c.link);
      box.appendChild(item);
    }

    // Acceptation implicite (phrase + bouton)
    for (const i of implicit) {
      const item = document.createElement("div");
      item.style.marginTop = "8px";
      item.appendChild(text(`➡ Acceptation implicite : « ${i.label} »`));
      if (i.buttons.length) item.appendChild(text(`Boutons : ${i.buttons.join(" / ")}`));
      addLink(item, i.link);
      box.appendChild(item);
    }

    show("yes", box);
  } catch (e) {
    // Ex: pages chrome://, Chrome Web Store, etc. où l'injection est interdite
    show("err", text("⚠️ Impossible d'analyser cette page : " + e.message));
  }
});
