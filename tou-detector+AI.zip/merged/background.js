// =====================================================================
// MODULE IA : lien des ToU -> texte -> Groq -> JSON structuré
// Messages acceptés (kind : "tou" par défaut, ou "cookies") :
//   { type: "ANALYZE_LINK", url,  kind } -> ouvre le lien, lit le texte, l'analyse
//   { type: "ANALYZE_TOU",  text, kind } -> analyse directement un texte
// Réponse : { ok: true, result } ou { ok: false, error }
// =====================================================================

const apiKey = "colle_ta_vraie_cle_ici";
const MODEL = "openai/gpt-oss-120b";
const MAX_CHARS = 40000; // limite de texte envoyé à Groq
const MIN_CHARS = 300;   // en dessous, le texte est trop court pour être des ToU

const PROMPT_TOU = `Tu es un expert en protection de la vie privée et en droit du numérique.
On te donne le texte de conditions d'utilisation ou d'une politique de confidentialité.

Règles :
- Base-toi UNIQUEMENT sur le texte fourni. N'invente rien.
- Si une information est absente du texte, écris "non précisé" au lieu de deviner.
- Écris en français, dans un langage simple, sans jargon juridique.
- Si le texte n'est pas des conditions d'utilisation, mets "valid_document" à false et laisse le reste vide.

Réponds UNIQUEMENT avec un objet JSON valide (sans texte autour, sans markdown), avec exactement ces champs :

{
  "valid_document": true,
  "summary": "résumé en 2 à 4 phrases",
  "key_points": ["5 à 8 points clés courts"],
  "data_practices": {
    "data_collected": ["types de données collectées"],
    "purposes": ["raisons pour lesquelles elles sont utilisées"],
    "shared_with": ["catégories de tiers qui reçoivent les données"],
    "retention": "durée de conservation ou non précisé"
  },
  "risks": [
    { "title": "titre court", "severity": "low | medium | high", "explanation": "1 phrase", "quote": "extrait de moins de 20 mots, ou vide" }
  ],
  "criteria": {
    "sells_data_to_third_parties": 0,
    "shares_with_advertisers": 0,
    "tracking_and_profiling": 0,
    "sensitive_data_collected": 0,
    "indefinite_retention": 0,
    "no_deletion_right": 0,
    "broad_content_license": 0,
    "unilateral_changes": 0,
    "forced_arbitration": 0,
    "location_tracking": 0,
    "vague_language": 0
  }
}

Pour chaque champ de "criteria" : 0 = non ou non mentionné, 1 = partiel ou flou, 2 = oui, clairement.`;

// Second prompt : politique de cookies ou texte d'un bandeau de cookies
const PROMPT_COOKIES = `Tu es un expert en protection de la vie privée et en cookies / traceurs web.
On te donne le texte d'une politique de cookies, d'un bandeau de consentement aux cookies, ou d'une politique de confidentialité qui parle de cookies.

Règles :
- Base-toi UNIQUEMENT sur le texte fourni. N'invente rien.
- Ne traite que ce qui concerne les cookies, traceurs et technologies similaires.
- Si une information est absente du texte, écris "non précisé" au lieu de deviner.
- Écris en français, dans un langage simple, sans jargon.
- Si le texte ne parle pas du tout de cookies ou de traceurs, mets "valid_document" à false et laisse le reste vide.

Réponds UNIQUEMENT avec un objet JSON valide (sans texte autour, sans markdown), avec exactement ces champs :

{
  "valid_document": true,
  "summary": "résumé en 2 à 4 phrases",
  "key_points": ["4 à 8 points clés courts"],
  "categories": [
    { "name": "necessary | functional | analytics | advertising | social | other", "purpose": "à quoi ils servent", "examples": ["noms de cookies ou services cités"] }
  ],
  "third_parties": ["entreprises ou services tiers cités, ou le nombre de partenaires s'il est donné"],
  "durations": "durées de vie mentionnées, ou non précisé",
  "user_controls": "comment l'utilisateur peut refuser ou gérer ses choix, ou non précisé",
  "risks": [
    { "title": "titre court", "severity": "low | medium | high", "explanation": "1 phrase", "quote": "extrait de moins de 20 mots, ou vide" }
  ],
  "criteria": {
    "advertising_cookies": 0,
    "cross_site_tracking": 0,
    "third_party_cookies": 0,
    "long_duration": 0,
    "no_easy_opt_out": 0,
    "consent_assumed": 0,
    "data_shared_with_ad_networks": 0,
    "fingerprinting_or_profiling": 0,
    "vague_language": 0
  }
}

Pour chaque champ de "criteria" : 0 = non ou non mentionné, 1 = partiel ou flou, 2 = oui, clairement.
"long_duration" : 2 si des cookies durent plus de 12 mois. "consent_assumed" : 2 si continuer à naviguer vaut acceptation ou si des cases sont précochées.`;

const PROMPTS = { tou: PROMPT_TOU, cookies: PROMPT_COOKIES };

// ---------- 1. Envoi du texte à Groq ----------

// kind : "tou" (conditions d'utilisation) ou "cookies" (politique ou bandeau de cookies)
async function analyser(texte, kind = "tou", minChars = MIN_CHARS) {
  const propre = (texte || "").trim();
  if (propre.length < minChars) {
    throw new Error("Texte trop court pour être analysé.");
  }

  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: MODEL,
      temperature: 0.1,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: PROMPTS[kind] || PROMPTS.tou },
        { role: "user", content: propre.slice(0, MAX_CHARS) },
      ],
    }),
  });

  if (!res.ok) {
    throw new Error(`Erreur Groq ${res.status} : ${await res.text()}`);
  }

  const data = await res.json();
  const contenu = data.choices?.[0]?.message?.content;

  let resultat;
  try {
    resultat = JSON.parse(contenu);
  } catch {
    throw new Error("Le modèle n'a pas renvoyé un JSON valide.");
  }

  resultat.kind = kind;
  resultat.truncated = propre.length > MAX_CHARS;
  return resultat;
}

// ---------- 2. Lecture du texte d'une page à partir de son lien ----------

// Exécutée DANS la page : doit rester autonome (aucune variable extérieure).
function lireTextePage() {
  const clone = (document.querySelector("main, article, [role='main']") || document.body).cloneNode(true);
  clone
    .querySelectorAll("script, style, noscript, svg, iframe, nav, footer, form, button, img, video, audio")
    .forEach((el) => el.remove());
  const text = (clone.innerText || clone.textContent || "")
    .replace(/ /g, " ")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n\s*\n+/g, "\n\n")
    .trim();
  return { title: document.title, text };
}

function attendre(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// Attend que l'onglet ait fini de charger (20 s maximum)
function attendreChargement(tabId) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("La page des ToU met trop de temps à charger."));
    }, 20000);

    function listener(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// Ouvre le lien dans un onglet inactif (sans cliquer sur la page de l'utilisateur),
// lit le texte une fois la page chargée, puis ferme l'onglet.
async function texteDepuisLien(url) {
  if (!/^https?:\/\//i.test(url || "")) {
    throw new Error("Lien invalide : seules les adresses http(s) sont acceptées.");
  }

  const tab = await chrome.tabs.create({ url, active: false });
  try {
    await attendreChargement(tab.id);
    await attendre(1500); // laisse le temps aux pages construites en JavaScript

    let page = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: lireTextePage }))[0]?.result;

    // Texte trop court : la page se construit peut-être encore, on réessaie une fois
    if (!page || page.text.length < MIN_CHARS) {
      await attendre(2500);
      page = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: lireTextePage }))[0]?.result;
    }

    if (!page || page.text.length < MIN_CHARS) {
      throw new Error("Impossible de lire le texte de cette page (trop court ou vide).");
    }
    return page;
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

// ---------- 3. Réception des messages du popup ----------

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const kind = message?.kind === "cookies" ? "cookies" : "tou";

  if (message?.type === "ANALYZE_LINK") {
    (async () => {
      const page = await texteDepuisLien(message.url);
      const result = await analyser(page.text, kind);
      return { ok: true, result, source: { url: message.url, title: page.title, chars: page.text.length } };
    })()
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true; // réponse asynchrone
  }

  if (message?.type === "ANALYZE_TOU") {
    // Texte envoyé directement (ex : texte d'un bandeau de cookies) : seuil plus bas
    analyser(message.text, kind, kind === "cookies" ? 100 : MIN_CHARS)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});
