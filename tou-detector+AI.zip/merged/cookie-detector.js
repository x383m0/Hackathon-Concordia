// Injecté dans la page par popup.js (comme detector.js).
// Détecte :
//   1. les bandeaux de cookies (texte qui parle de cookies + boutons Accepter / Refuser / Gérer)
//   2. les liens vers une politique de cookies (bandeau, pied de page, etc.)
// La valeur de la dernière expression est renvoyée au popup.
(() => {
  // ---------- Regex ----------

  // Mots qui montrent qu'un bloc parle de cookies
  const COOKIE_WORD = /(cookie|traceur|t[ée]moins? de connexion|tracking)/i;

  // Libellé d'un bouton de bandeau de cookies (anglais et français)
  const CONSENT_BUTTON = /^(accept( all)?( cookies)?|allow( all)?( cookies)?|i accept|i agree|i do not agree|i don['’]t agree|do not agree|agree( and close)?|got it|ok|okay|tout accepter|accepter( tout| les cookies| et fermer)?|j['’]accepte|je refuse|autoriser( tout)?|reject( all)?( cookies)?|decline|deny|refuse|only necessary|necessary only|tout refuser|refuser( tout| les cookies)?|continuer sans accepter|manage( cookies| preferences| settings| choices| options)?|cookie settings|customi[sz]e( settings| cookies)?|preferences|personnaliser|g[ée]rer( les cookies| mes choix| les pr[ée]f[ée]rences| les options)?|param[ée]trer|param[èe]tres( des cookies)?|more options|plus d['’]options)$/i;

  // Texte d'un lien vers la politique de cookies
  const POLICY_PHRASE = /(cookies?\s*(policy|policies|notice|statement)|(politique|avis|charte|d[ée]claration)\s+(relative\s+aux\s+|sur\s+les\s+|de\s+|des\s+|d['’]utilisation\s+des\s+)?cookies?)/i;
  const POLICY_EXACT = /^cookies?$/i;

  // Segment d'URL (ex: /legal/cookie-policy)
  const POLICY_SEGMENT = /^(cookie[-_]?(policy|policies|notice|statement)|cookies?|politique[-_](de[-_])?cookies?)(\.html?|\.php)?$/i;

  // Lien vers la politique de confidentialité (utilisé en secours)
  const PRIVACY = /(privacy|confidentialit|vie priv[ée]e|donn[ée]es personnelles)/i;

  const BUTTONS = 'button, input[type="submit"], input[type="button"], [role="button"], a[role="button"]';

  const MAX_LEVELS = 8;    // combien de parents on remonte depuis un bouton
  const BANNER_MAX = 3000; // taille max (caractères) du bloc d'un bandeau

  // ---------- Outils ----------

  function clean(t) {
    return (t || "").replace(/\s+/g, " ").trim();
  }

  // Texte réellement visible (ignore le code et les éléments cachés)
  function visibleText(el) {
    return clean(el.innerText !== undefined ? el.innerText : el.textContent);
  }

  function isVisible(el) {
    return el.getClientRects().length > 0;
  }

  function buttonLabel(b) {
    return clean(b.textContent) || clean(b.getAttribute("value")) || clean(b.getAttribute("aria-label"));
  }

  function isCookieUrl(href) {
    try {
      return new URL(href).pathname.split("/").some((s) => POLICY_SEGMENT.test(s));
    } catch {
      return false;
    }
  }

  function isCookieText(raw) {
    const t = clean(raw);
    return t.length > 0 && t.length <= 60 && (POLICY_PHRASE.test(t) || POLICY_EXACT.test(t));
  }

  function isCookieLink(a) {
    return isCookieText(a.textContent) || isCookieText(a.getAttribute("aria-label")) || isCookieUrl(a.href);
  }

  function isPrivacyLink(a) {
    const t = clean(a.textContent);
    return t.length > 0 && t.length <= 60 && PRIVACY.test(t);
  }

  // ---------- Liens vers la politique de cookies (toute la page) ----------

  const pageLinks = [];
  const seenHref = new Set();
  for (const a of document.querySelectorAll("a[href]")) {
    if (!/^https?:/i.test(a.href) || !isCookieLink(a) || seenHref.has(a.href)) continue;
    seenHref.add(a.href);
    pageLinks.push({ text: clean(a.textContent).slice(0, 60), href: a.href });
  }

  // ---------- Bandeaux de cookies ----------

  const banners = [];
  const seenContainers = new Set();

  for (const b of document.querySelectorAll(BUTTONS)) {
    const label = buttonLabel(b);
    if (!label || label.length > 40 || !CONSENT_BUTTON.test(label) || !isVisible(b)) continue;

    // On remonte jusqu'au plus petit bloc qui parle de cookies
    let container = null;
    let p = b.parentElement;
    for (let i = 0; i < MAX_LEVELS && p; i++, p = p.parentElement) {
      const t = visibleText(p);
      if (t.length > BANNER_MAX) break;
      if (COOKIE_WORD.test(t)) { container = p; break; }
    }
    if (!container || seenContainers.has(container)) continue;

    // Un bloc déjà couvert par un bandeau plus grand n'est pas compté deux fois
    if ([...seenContainers].some((c) => c.contains(container) || container.contains(c))) continue;
    seenContainers.add(container);

    const buttons = [...container.querySelectorAll(BUTTONS)]
      .map(buttonLabel)
      .filter((l) => l && l.length <= 40 && CONSENT_BUTTON.test(l));

    // Lien à analyser : politique de cookies du bandeau > de la page > confidentialité du bandeau
    const inBanner = [...container.querySelectorAll("a[href]")].filter((a) => /^https?:/i.test(a.href));
    const cookieInBanner = inBanner.find(isCookieLink);
    const privacyInBanner = inBanner.find(isPrivacyLink);

    let link = null;
    let linkKind = null;
    if (cookieInBanner) { link = cookieInBanner.href; linkKind = "cookie"; }
    else if (pageLinks.length) { link = pageLinks[0].href; linkKind = "page"; }
    else if (privacyInBanner) { link = privacyInBanner.href; linkKind = "privacy"; }

    const fullText = visibleText(container);

    banners.push({
      label: fullText.slice(0, 160),
      text: fullText, // texte complet du bandeau : analysable même sans lien
      buttons: [...new Set(buttons)].slice(0, 4),
      link,
      linkKind
    });
  }

  return {
    found: banners.length > 0 || pageLinks.length > 0,
    banners,
    policyLinks: pageLinks.slice(0, 5),
    page: location.href
  };
})();
