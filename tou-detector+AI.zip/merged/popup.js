const resultDiv = document.getElementById("result");

function show(cls, content) {
  resultDiv.className = cls;
  resultDiv.style.display = "block";
  resultDiv.replaceChildren(content);
}

function text(str) {
  const p = document.createElement("div");
  p.textContent = str; // textContent: le texte vient de la page, jamais en innerHTML
  return p;
}

function safeLink(url) {
  // N'accepte que http(s) pour éviter les liens javascript:
  if (!/^https?:\/\//i.test(url)) return null;
  const a = document.createElement("a");
  a.href = url;
  a.target = "_blank";
  a.textContent = url;
  return a;
}

function addLink(parent, url) {
  const link = url && safeLink(url);
  if (link) parent.appendChild(link);
}

// =====================================================================
// MODULE IA : bouton « Analyser avec l'IA » sous chaque lien de ToU
// =====================================================================

const aiDiv = document.getElementById("ai");

function showAi(content, isError = false) {
  aiDiv.style.display = "block";
  const box = document.createElement("div");
  box.className = "ai-box" + (isError ? " ai-error" : "");
  box.appendChild(content);
  aiDiv.replaceChildren(box);
}

function renderAiResult(response) {
  const r = response.result;
  const box = document.createElement("div");

  if (r.valid_document === false) {
    box.appendChild(text(r.kind === "cookies"
      ? "⚠️ Ce texte ne semble pas parler de cookies."
      : "⚠️ Cette page ne semble pas être des conditions d'utilisation."));
    return showAi(box);
  }

  box.appendChild(text(r.summary || ""));

  if (Array.isArray(r.key_points) && r.key_points.length) {
    const ul = document.createElement("ul");
    for (const p of r.key_points) {
      const li = document.createElement("li");
      li.textContent = p;
      ul.appendChild(li);
    }
    box.appendChild(ul);
  }

  // Analyse des cookies : infos en plus
  if (r.kind === "cookies") {
    if (Array.isArray(r.third_parties) && r.third_parties.length) {
      box.appendChild(text("Tiers : " + r.third_parties.join(", ")));
    }
    if (r.durations) box.appendChild(text("Durées : " + r.durations));
    if (r.user_controls) box.appendChild(text("Vos choix : " + r.user_controls));
  }

  if (r.truncated) {
    box.appendChild(text("(Texte très long : seule la première partie a été analysée.)"));
  }

  // JSON complet : à transmettre au calcul du T.O.U. Score et à l'affichage final
  const ta = document.createElement("textarea");
  ta.value = JSON.stringify(r, null, 2);
  ta.readOnly = true;
  ta.rows = 6;
  box.appendChild(ta);

  showAi(box);
}

// Envoie une demande au background (lien ou texte) et affiche le résultat.
// payload : { type: "ANALYZE_LINK", url, kind } ou { type: "ANALYZE_TOU", text, kind }
async function runAnalysis(payload, btn, label) {
  btn.disabled = true;
  btn.textContent = "Analyse en cours…";
  showAi(text("⏳ Analyse par l'IA (quelques secondes)…"));

  try {
    const response = await chrome.runtime.sendMessage(payload);
    if (!response?.ok) throw new Error(response?.error || "Erreur inconnue");
    renderAiResult(response);
  } catch (e) {
    showAi(text("⚠️ " + e.message), true);
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
}

// kind : "tou" (par défaut) ou "cookies"
function addAnalyzeButton(parent, url, kind = "tou", label = "Analyser avec l'IA") {
  if (!url || !/^https?:\/\//i.test(url)) return; // pas de lien : rien à analyser
  const btn = document.createElement("button");
  btn.textContent = label;
  btn.style.marginTop = "6px";
  btn.addEventListener("click", () => runAnalysis({ type: "ANALYZE_LINK", url, kind }, btn, label));
  parent.appendChild(btn);
}

// Analyse directe d'un texte (ex : texte d'un bandeau de cookies, sans lien)
function addAnalyzeTextButton(parent, textToAnalyze, kind, label) {
  const btn = document.createElement("button");
  btn.textContent = label;
  btn.style.marginTop = "6px";
  btn.addEventListener("click", () => runAnalysis({ type: "ANALYZE_TOU", text: textToAnalyze, kind }, btn, label));
  parent.appendChild(btn);
}

// =====================================================================
// MODULE IA : détection des cookies (bandeau + politique de cookies)
// Indépendant du détecteur de ToU : un second écouteur sur le même bouton.
// =====================================================================

const cookiesDiv = document.getElementById("cookies");

document.getElementById("check").addEventListener("click", async () => {
  cookiesDiv.style.display = "none";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const injected = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true }, // les bandeaux sont souvent dans une iframe
      files: ["cookie-detector.js"]
    });

    const frames = injected.map(r => r.result).filter(Boolean);
    const banners = frames.flatMap(f => f.banners);
    const policyLinks = [...new Map(frames.flatMap(f => f.policyLinks).map(l => [l.href, l])).values()];

    const box = document.createElement("div");

    if (banners.length === 0 && policyLinks.length === 0) {
      box.appendChild(text("🍪 Aucun bandeau ni politique de cookies détecté."));
    }

    // Bandeaux de cookies
    for (const b of banners) {
      const item = document.createElement("div");
      item.style.marginTop = "8px";
      item.appendChild(text(`🍪 Bandeau de cookies : « ${b.label} »`));
      if (b.buttons.length) item.appendChild(text(`Boutons : ${b.buttons.join(" / ")}`));
      addLink(item, b.link);
      if (b.linkKind === "privacy") {
        item.appendChild(text("(politique de confidentialité : pas de politique de cookies séparée trouvée)"));
      }
      addAnalyzeButton(item, b.link, "cookies", "Analyser le lien (cookies)");
      addAnalyzeTextButton(item, b.text, "cookies", "Analyser le texte du bandeau");
      box.appendChild(item);
    }

    // Liens vers une politique de cookies non déjà proposés par un bandeau
    const shown = new Set(banners.map(b => b.link));
    for (const l of policyLinks.filter(l => !shown.has(l.href))) {
      const item = document.createElement("div");
      item.style.marginTop = "8px";
      item.appendChild(text(`🍪 Politique de cookies : « ${l.text} »`));
      addLink(item, l.href);
      addAnalyzeButton(item, l.href, "cookies", "Analyser la politique (cookies)");
      box.appendChild(item);
    }

    cookiesDiv.style.display = "block";
    cookiesDiv.replaceChildren(box);
  } catch (e) {
    cookiesDiv.style.display = "block";
    cookiesDiv.replaceChildren(text("⚠️ Cookies : " + e.message));
  }
});

// =====================================================================

document.getElementById("check").addEventListener("click", async () => {
  aiDiv.style.display = "none"; // efface l'ancienne analyse
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // Injecte detector.js dans la page ET dans toutes ses iframes
    const injected = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ["detector.js"]
    });

    // Un résultat par cadre (page principale + iframes) : on les regroupe
    const frames = injected.map(r => r.result).filter(Boolean);
    const checkboxes = frames.flatMap(f => f.checkboxes);
    const implicit = frames.flatMap(f => f.implicit);

    if (checkboxes.length + implicit.length === 0) {
      const box = document.createElement("div");
      box.appendChild(text("❌ Aucun ToU à accepter détecté."));

      // Diagnostic : ce que chaque cadre contient
      const diag = document.createElement("div");
      diag.style.cssText = "margin-top:8px;font-size:11px;opacity:.85";
      diag.appendChild(text(`Cadres analysés : ${frames.length}`));
      for (const f of frames) {
        const d = f.debug;
        diag.appendChild(text(
          `• ${f.page.slice(0, 55)} → liens ToU: ${d.termsLinks}, boutons: ${d.buttons}, cases: ${d.checkboxes}`
        ));
      }
      box.appendChild(diag);

      // Diagnostic détaillé à copier-coller pour comprendre pourquoi rien n'est détecté
      const report = JSON.stringify(frames.map(f => ({ page: f.page, debug: f.debug })), null, 1);
      const ta = document.createElement("textarea");
      ta.value = report;
      ta.readOnly = true;
      ta.rows = 5;
      ta.style.cssText = "width:100%;margin-top:8px;font-size:10px;box-sizing:border-box";
      const copy = document.createElement("button");
      copy.textContent = "Copier le diagnostic";
      copy.style.marginTop = "6px";
      copy.addEventListener("click", () => {
        ta.select();
        document.execCommand("copy");
        copy.textContent = "Copié ✓";
      });
      box.appendChild(ta);
      box.appendChild(copy);

      show("no", box);
      return;
    }

    const box = document.createElement("div");
    const total = checkboxes.length + implicit.length;
    box.appendChild(text(`✅ ${total} acceptation${total > 1 ? "s" : ""} de ToU détectée${total > 1 ? "s" : ""}`));

    // Cases à cocher
    for (const c of checkboxes) {
      const item = document.createElement("div");
      item.style.marginTop = "8px";
      item.appendChild(text(`${c.checked ? "☑" : "☐"} Case à cocher : « ${c.label} »`));
      addLink(item, c.link);
      addAnalyzeButton(item, c.link); // MODULE IA
      box.appendChild(item);
    }

    // Acceptation implicite (phrase + bouton)
    for (const i of implicit) {
      const item = document.createElement("div");
      item.style.marginTop = "8px";
      item.appendChild(text(`➡ Acceptation implicite : « ${i.label} »`));
      if (i.buttons.length) item.appendChild(text(`Boutons : ${i.buttons.join(" / ")}`));
      addLink(item, i.link);
      addAnalyzeButton(item, i.link); // MODULE IA
      box.appendChild(item);
    }

    show("yes", box);
  } catch (e) {
    // Ex: pages chrome://, Chrome Web Store, etc. où l'injection est interdite
    show("err", text("⚠️ Impossible d'analyser cette page : " + e.message));
  }
});
